# -*- encoding: utf-8 -*-
# © 2013 Mikrointeracciones de México (contacto@mikrointeracciones.com)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import res_partner
from . import transport_catalogs
from . import account_journal
from . import account_move
from . import account_transport
from . import fleet
# import ir_attachment_payment
